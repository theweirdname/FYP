import 'package:flutter/material.dart';
import './Login.dart';

class DrawerCodeOnly extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return new Drawer(
      child: new ListView(
        children: <Widget>[
          new DrawerHeader(
            child: Text(""
                "Drawer",
              style: TextStyle(
                fontFamily: 'RobotoCondensed',
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),),
            decoration: new BoxDecoration(
              color: Colors.lightBlueAccent,
            ),
          ),
          ListTile(
            title: new Text("Driver Login"),
            leading: Icon(Icons.account_circle),
            onTap: (){
              Navigator.push(context, new MaterialPageRoute(builder: (context) => new LoginPage(),),);
            },
          ),
        ],
      ),
    );
  }
}