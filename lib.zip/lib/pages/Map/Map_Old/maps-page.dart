import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:scoped_model/scoped_model.dart';
import 'map-model.dart';
import 'package:utemshuttle/datamodels/user_location.dart';
import 'package:location/location.dart';
import 'package:utemshuttle/services/location_service.dart';
import 'dart:async';
import 'dart:developer';
import 'package:provider/provider.dart';

class MapPage extends StatelessWidget {
  const MapPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    UserLocation _currentLocation = Provider.of<UserLocation>(context);

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Buses around you'),
      ),
      body: ScopedModelDescendant<MapModel>(
        builder: (context, child, model) {
          if (model.latLng != null)
            return GoogleMap(
              markers: [
                Marker(
                    position: model.latLng,
                    markerId: MarkerId('bas1'),
                    icon: model.marker ?? BitmapDescriptor.defaultMarker
                )
              ].toSet(),
              onMapCreated: (map) => model.googleMapController = map,
              myLocationButtonEnabled: false,
              myLocationEnabled: true,
              initialCameraPosition:
              CameraPosition(zoom: 15.0, target: model.latLng),
            );
          else
            return GoogleMap(
              markers: [
                Marker(
                    position: LatLng(
                        _currentLocation.latitude, _currentLocation.longitude),
                    markerId: MarkerId('bas1'),
                    icon: model.marker ?? BitmapDescriptor.defaultMarker
                )
              ].toSet(),
              onMapCreated: (map) => model.googleMapController = map,
              myLocationButtonEnabled: false,
              myLocationEnabled: true,
              initialCameraPosition:
              CameraPosition(zoom: 15.0,
                  target: LatLng(
                      _currentLocation.latitude, _currentLocation.longitude)),
            );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.my_location),
        onPressed: () {

        },
      ),
    );
  }
}