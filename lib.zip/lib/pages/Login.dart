import 'package:flutter/material.dart';
import 'package:utemshuttle/pages/Map.dart';
import 'package:utemshuttle/pages/Driver_page.dart';
import 'package:utemshuttle/pages/Map.dart';
import '../common/app_card.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:utemshuttle/services/location_service.dart';
import 'package:utemshuttle/datamodels/user_location.dart';
import 'package:utemshuttle/pages/drawer_code_driver.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  String _email, _password;

  static const routeName= '/loginPage';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Driver Login'),
      ),
      body: Form(
        key: _formkey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            AppCard(
              child: Text(
                'Driver Login', style: TextStyle(fontSize: 32.0),
                textAlign: TextAlign.center,
              ),
            ),
            AppCard(
              child: Container(
                //margin:EdgeInsets.only(top:20),
                  child: Column(
                    children: <Widget>[
                      TextFormField(
                        validator: (value) => value.isEmpty ? 'Email can\'t be empty' : null,
                        onSaved: (input) => _email = input,
                        decoration: InputDecoration(
                            labelText: "Driver ID"
                        ),
                      ),
                      TextFormField(
                        validator: (value) => value.isEmpty ? 'Password can\'t be empty' : null,
                        onSaved: (input) => _password = input,
                        decoration: InputDecoration(
                            labelText: "Password"
                        ),
                        obscureText: true,
                      ),
                      Container(
                        width: double.infinity,
                        margin: EdgeInsets.only(top: 20),
                        child: FlatButton(
                          color: Colors.blueAccent,
                          textColor: Colors.white,
                          onPressed: signIN,
                          child: Text("Login"),
                        ),
                      ),
                    ],
                  )
              ),
            )
          ],
        ),
      ),//container
    );//scaffold
  }
  Future<void> signIN() async{
    final formState = _formkey.currentState;
    if(formState.validate()){
      formState.save();
      try{
        FirebaseUser user = (await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _password)).user;

        Navigator.push(context, MaterialPageRoute(builder: (context) => build5(context),),);
      } catch(e){
        print(e.message);
      }
    }
  }

  Widget build5(BuildContext context) {
    return StreamProvider<UserLocation>(
        builder: (context) => LocationService().locationStream,
        child: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Text('UTeM Shuttle Driver'),
          ),
          body: Map(),
          drawer: DrawerCodeDriverOnly(),
        )
    );
  }
}