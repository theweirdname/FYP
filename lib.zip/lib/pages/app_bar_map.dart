import 'package:flutter/material.dart';
import 'package:utemshuttle/pages/StudentMap.dart';
import 'package:utemshuttle/pages/drawer_code.dart';
import 'package:provider/provider.dart';
import 'package:utemshuttle/services/location_service.dart';
import 'package:utemshuttle/datamodels/user_location.dart';

void main() => runApp(AppBarMap());

class AppBarMap extends StatelessWidget {
  static const routeName = '/';

  @override
  Widget build(BuildContext context) {
    return StreamProvider<UserLocation>(
      builder: (context) => LocationService().locationStream,
      child: Scaffold(
        appBar: AppBar(
        centerTitle: true,
        title: Text('UTeM Shuttle Student'),
    ),
        drawer: DrawerCodeOnly(),
         body: StudentMap(),
      )
    );
  }
}