import 'package:flutter/material.dart';
import 'package:utemshuttle/pages/app_bar_map.dart';
import 'package:utemshuttle/pages/add_place_screen.dart';

import 'package:utemshuttle/providers/great_places.dart';
import 'package:provider/provider.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  Icon actionIcon = new Icon(Icons.dehaze);

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
        value: GreatPlaces(),
      child: MaterialApp(
      title: 'UTeM Shuttle',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AppBarMap(),
        routes: {
    AddPlaceScreen.routeName: (ctx) => AddPlaceScreen(),
    }
      ),
    );
  }
}