import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:utemshuttle/datamodels/user_location.dart';
import 'package:location/location.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class StudentMap extends StatefulWidget {
  @override
  _StudentMapState createState() => _StudentMapState();

}

final databaseReference = FirebaseDatabase.instance.reference();
final databaseReference2 = Firestore.instance;

void createRecord(String latitude,String longitude){

  databaseReference2.collection("text").add({
    'driver': 'Driver',
    'latitude': latitude,
    'longitude': longitude,
  }).then((_) {
    print("One document added.");
  });

}

void updateData(String latitude,String longitude,BuildContext context) {
  DocumentReference documentReference =
  Firestore.instance.collection("text").document("q0MQuwckzzcyrtZ5l09A");
  documentReference.get().then((datasnapshot) {
    if (datasnapshot.exists) {
      print(datasnapshot.data['latitude'].toString());

      Marker resultMarker = Marker(
          markerId: MarkerId(datasnapshot.data['driver'].toString()),
          infoWindow: InfoWindow(
              title: "Driver"),
          position: LatLng(
              double.parse(datasnapshot.data['latitude'].toString()),
              double.parse(datasnapshot.data['longitude'].toString())));

      markers.add(resultMarker);

      Marker resultMarker2 = Marker(
          markerId: MarkerId("Student"),
          infoWindow: InfoWindow(
              title: "Student"),
          position: LatLng(double.parse(latitude),
              double.parse(longitude)));

      markers.add(resultMarker2);
    }
    else {
      print("No such user");
    }
  });
}

GoogleMapController mapController;

Set<Marker> markers = Set();

class _StudentMapState extends State<StudentMap> {
  GoogleMapController mapController;
  Location location = new Location();

  build(context) {
    UserLocation _currentLocation = Provider.of<UserLocation>(context);
    updateData(_currentLocation.latitude.toString(),_currentLocation.longitude.toString(),context);
    return Stack(children: [
      GoogleMap(
        onMapCreated: _onMapCreated,
        myLocationEnabled: true,
        initialCameraPosition:
        CameraPosition(target: LatLng(_currentLocation.latitude,_currentLocation.longitude),
            zoom: 15),
        markers: markers,
      )
    ],
    );
  }

  _onMapCreated(GoogleMapController controller) {
    setState(() {
      mapController = controller;
    });
  }
}