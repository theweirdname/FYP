import 'package:flutter/material.dart';
import 'package:utemshuttle/pages/places_list_screen.dart';
import 'package:provider/provider.dart';
import 'package:utemshuttle/providers/great_places.dart';
import 'package:utemshuttle/pages/add_place_screen.dart';

class DrawerCodeDriverOnly extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return new ChangeNotifierProvider.value(
      value: GreatPlaces(),
    child: Drawer(
      child: new ListView(
        children: <Widget>[
          new DrawerHeader(
            child: Text(""
                " Driver Drawer",
              style: TextStyle(
                fontFamily: 'RobotoCondensed',
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),),
            decoration: new BoxDecoration(
              color: Colors.lightBlueAccent,
            ),
          ),
          ListTile(
            title: new Text("Incident Log"),
            leading: Icon(Icons.account_circle),
            onTap: (){
              Navigator.push(context, new MaterialPageRoute(builder: (context) => new PlacesListScreen(),),);
            },
          ),
        ],
      ),
    ),
    );
  }
}