import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:utemshuttle/datamodels/user_location.dart';
import 'package:location/location.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Map extends StatefulWidget {
  @override
  _MapState createState() => _MapState();
}

final databaseReference = FirebaseDatabase.instance.reference();
final databaseReference2 = Firestore.instance;

void createRecord(String latitude,String longitude){

  databaseReference2.collection("text").add({
    'driver': 'Driver',
    'latitude': latitude,
    'longitude': longitude,
  }).then((_) {
    print("One document added.");
  });

}

void updateData(String latitude,String longitude){
  databaseReference2.collection("text").document("q0MQuwckzzcyrtZ5l09A").updateData({
    'driver': 'Driver',
    'latitude': latitude,
    'longitude': longitude,
  }).then((_) {
    print("One document added.");
  });
}

class _MapState extends State<Map> {
  GoogleMapController mapController;
  Location location = new Location();

  build(context) {
    UserLocation _currentLocation = Provider.of<UserLocation>(context);
    updateData(_currentLocation.latitude.toString(),_currentLocation.longitude.toString());
    return Stack(children: [
      GoogleMap(
        initialCameraPosition: CameraPosition(
            target: LatLng(_currentLocation.latitude,_currentLocation.longitude),
            zoom: 15
        ),
        onMapCreated: _onMapCreated,
        myLocationEnabled: true,
        compassEnabled: true,
      ),
    ],
    );
  }

  _onMapCreated(GoogleMapController controller) {
    setState(() {
      mapController = controller;
    });
  }
}