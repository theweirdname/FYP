import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import './drawer_code.dart';

class DriverScreen extends StatefulWidget {
  const DriverScreen({Key key, @required this.user}): super(key:key);
  final FirebaseUser user;

  @override
  _DriverScreenState createState() => _DriverScreenState();
}

class _DriverScreenState extends State<DriverScreen> {
  bool _driving = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Driver Area'),
        centerTitle: true,
        backgroundColor: Colors.blue[600],
      ),
      drawer: DrawerCodeOnly(),
      body: Column(children: <Widget> [
        Expanded(child: ListView(
          children: <Widget>[
            SwitchListTile(
              title: Text(
                  'Start-Driving',
                style:  Theme.of(context).textTheme.title,),
              value: _driving,
              subtitle: Text(
                  'Other user will be able to see your location'),
              // TODO: Track driver location
              onChanged: (newValue){
                setState(() {
                  _driving = newValue;
                });
              },

            ),
          ],
        ),),

      ],
      ),

    );
  }
}